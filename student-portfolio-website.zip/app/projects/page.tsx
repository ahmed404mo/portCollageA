"use client"

import { motion } from "framer-motion"
import { ArrowRight } from "lucide-react"
import { ProgrammingLanguages } from "@/components/animated-elements"

export default function ProjectsPage() {
  const projects = [
    {
      id: 1,
      title: "Project Title One",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
      tags: ["React", "Tailwind", "Next.js"],
      image: "/project-one.jpg",
    },
    {
      id: 2,
      title: "Project Title Two",
      description: "Sed do eiusmod tempor incididunt ut labore et dolore magna.",
      tags: ["JavaScript", "CSS", "HTML"],
      image: "/project-two.jpg",
    },
    {
      id: 3,
      title: "Project Title Three",
      description: "Ut enim ad minim veniam, quis nostrud exercitation ullamco.",
      tags: ["Python", "React", "API"],
      image: "/project-three.jpg",
    },
    {
      id: 4,
      title: "Project Title Four",
      description: "Duis aute irure dolor in reprehenderit in voluptate velit.",
      tags: ["TypeScript", "Next.js", "Database"],
      image: "/project-four.jpg",
    },
    {
      id: 5,
      title: "Project Title Five",
      description: "Excepteur sint occaecat cupidatat non proident, sunt in culpa.",
      tags: ["React", "Node.js", "MongoDB"],
      image: "/project-five.jpg",
    },
    {
      id: 6,
      title: "Project Title Six",
      description: "Qui officia deserunt mollit anim id est laborum sed ut.",
      tags: ["Vue.js", "Express", "PostgreSQL"],
      image: "/project-six.jpg",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-[#F8F9FA] to-white relative overflow-hidden">
      <ProgrammingLanguages />

      {/* Header Section */}
      <section className="relative pt-20 pb-12 px-4 sm:px-6 lg:px-8 z-10">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center space-y-4"
          >
            <h1 className="text-5xl md:text-6xl font-bold text-[#2D3748]">My Projects</h1>
            <p className="text-lg text-[#556B7F] max-w-2xl mx-auto">
              Explore a collection of projects showcasing creativity, technical skills, and educational innovation.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105"
              >
                {/* Project Image */}
                <div className="relative h-48 overflow-hidden bg-gradient-to-br from-[#FEE440]/20 to-[#00BBF9]/20">
                  <img
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>

                {/* Project Content */}
                <div className="p-6 space-y-4">
                  <h3 className="text-xl font-bold text-[#2D3748]">{project.title}</h3>
                  <p className="text-[#556B7F] text-sm leading-relaxed">{project.description}</p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-3 py-1 text-xs font-semibold bg-gradient-to-r from-[#FEE440]/20 to-[#00BBF9]/20 text-[#00BBF9] rounded-full border border-[#00BBF9]/30"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* View Button */}
                  <motion.button
                    whileHover={{ x: 5 }}
                    className="inline-flex items-center gap-2 text-[#00BBF9] font-semibold hover:text-[#9B5DE5] transition-colors mt-4"
                  >
                    View Project
                    <ArrowRight size={16} />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-[#2D3748]">Have a Project in Mind?</h2>
            <p className="text-lg text-[#556B7F] leading-relaxed">
              Let's collaborate and bring your ideas to life with creativity and technical expertise.
            </p>
            <a
              href="/contact"
              className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-[#9B5DE5] to-[#00F5D4] text-white font-semibold rounded-full hover:shadow-lg transition-all hover:scale-105"
            >
              Start a Project
              <ArrowRight size={20} />
            </a>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
