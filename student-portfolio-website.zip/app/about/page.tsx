"use client"

import { motion } from "framer-motion"
import { BookOpen, Heart, Lightbulb, Users } from "lucide-react"
import { ProgrammingLanguages } from "@/components/animated-elements"

export default function About() {
  const values = [
    {
      icon: BookOpen,
      title: "Lifelong Learning",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    },
    {
      icon: Heart,
      title: "Child-Centered",
      description: "Sed do eiusmod tempor incididunt ut labore et dolore magna.",
    },
    {
      icon: Lightbulb,
      title: "Innovation",
      description: "Ut enim ad minim veniam, quis nostrud exercitation ullamco.",
    },
    {
      icon: Users,
      title: "Collaboration",
      description: "Duis aute irure dolor in reprehenderit in voluptate velit.",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-[#F8F9FA] to-white relative overflow-hidden">
      <ProgrammingLanguages />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 px-4 sm:px-6 lg:px-8 z-10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-4"
          >
            <h1 className="text-5xl md:text-6xl font-bold text-[#2D3748]">About Ahmed</h1>
            <p className="text-xl text-[#556B7F]">Passionate educator and creative technologist</p>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-20">
            {/* Left - Image Placeholder */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="relative h-96 rounded-3xl overflow-hidden shadow-2xl">
                <div className="w-full h-full bg-gradient-to-br from-[#FEE440]/30 via-[#00BBF9]/30 to-[#9B5DE5]/30 flex items-center justify-center">
                  <div className="w-32 h-32 bg-gradient-to-br from-[#FEE440] to-[#00BBF9] rounded-full"></div>
                </div>
              </div>
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-br from-[#FEE440] to-[#00BBF9] rounded-full opacity-20 blur-2xl"
              />
            </motion.div>

            {/* Right - Bio */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              <div className="space-y-4">
                <h2 className="text-3xl font-bold text-[#2D3748]">My Journey</h2>
                <p className="text-lg text-[#556B7F] leading-relaxed">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et
                  dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.
                </p>
                <p className="text-lg text-[#556B7F] leading-relaxed">
                  Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                  Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est
                  laborum.
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-xl font-bold text-[#2D3748]">My Goals</h3>
                <ul className="space-y-2 text-[#556B7F]">
                  <li className="flex items-start gap-3">
                    <span className="text-[#00BBF9] font-bold mt-1 text-lg">→</span>
                    <span>Lorem ipsum dolor sit amet consectetur</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-[#00BBF9] font-bold mt-1 text-lg">→</span>
                    <span>Sed do eiusmod tempor incididunt ut labore</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-[#00BBF9] font-bold mt-1 text-lg">→</span>
                    <span>Ut enim ad minim veniam quis nostrud</span>
                  </li>
                </ul>
              </div>
            </motion.div>
          </div>

          {/* Values Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-12"
          >
            <div className="text-center space-y-4">
              <h2 className="text-4xl font-bold text-[#2D3748]">My Core Values</h2>
              <p className="text-lg text-[#556B7F]">What drives my passion for education</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {values.map((value, i) => {
                const Icon = value.icon
                return (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="p-8 rounded-2xl bg-gradient-to-br from-white to-[#F8F9FA] border-2 border-[#00BBF9]/20 hover:border-[#00BBF9]/50 transition-all hover:shadow-lg"
                  >
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-gradient-to-br from-[#FEE440] to-[#00BBF9] text-white">
                        <Icon size={24} />
                      </div>
                      <div className="space-y-2">
                        <h3 className="text-xl font-bold text-[#2D3748]">{value.title}</h3>
                        <p className="text-[#556B7F]">{value.description}</p>
                      </div>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Education Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white relative z-10">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="text-center space-y-4">
              <h2 className="text-4xl font-bold text-[#2D3748]">Education</h2>
              <p className="text-lg text-[#556B7F]">My academic background</p>
            </div>

            <div className="space-y-6">
              <div className="p-8 rounded-2xl bg-gradient-to-r from-[#FEE440]/10 to-[#00BBF9]/10 border-l-4 border-[#00BBF9]">
                <h3 className="text-2xl font-bold text-[#2D3748] mb-2">Faculty of Early Childhood Education</h3>
                <p className="text-[#556B7F] mb-3">Currently Studying</p>
                <p className="text-[#556B7F] leading-relaxed">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et
                  dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                  aliquip ex ea commodo consequat.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
