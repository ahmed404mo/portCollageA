"use client"

import { motion } from "framer-motion"
import { Award, Calendar, Building2 } from "lucide-react"
import { ProgrammingLanguages } from "@/components/animated-elements"

export default function CertificatesPage() {
  const certificates = [
    {
      id: 1,
      title: "Certificate Title One",
      issuer: "Organization Name",
      date: "January 2024",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
      image: "/cert-one.jpg",
    },
    {
      id: 2,
      title: "Certificate Title Two",
      issuer: "Institution Name",
      date: "December 2023",
      description: "Sed do eiusmod tempor incididunt ut labore et dolore magna.",
      image: "/cert-two.jpg",
    },
    {
      id: 3,
      title: "Certificate Title Three",
      issuer: "Academy Name",
      date: "November 2023",
      description: "Ut enim ad minim veniam, quis nostrud exercitation ullamco.",
      image: "/cert-three.jpg",
    },
    {
      id: 4,
      title: "Certificate Title Four",
      issuer: "Training Center",
      date: "October 2023",
      description: "Duis aute irure dolor in reprehenderit in voluptate velit.",
      image: "/cert-four.jpg",
    },
    {
      id: 5,
      title: "Certificate Title Five",
      issuer: "Educational Institute",
      date: "September 2023",
      description: "Excepteur sint occaecat cupidatat non proident, sunt in culpa.",
      image: "/cert-five.jpg",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-[#F8F9FA] to-white relative overflow-hidden">
      <ProgrammingLanguages />

      {/* Header Section */}
      <section className="relative pt-20 pb-12 px-4 sm:px-6 lg:px-8 z-10">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center space-y-4"
          >
            <h1 className="text-5xl md:text-6xl font-bold text-[#2D3748]">Certificates & Achievements</h1>
            <p className="text-lg text-[#556B7F] max-w-2xl mx-auto">
              Recognition of my professional development and continuous learning journey.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Certificates Timeline */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          <div className="space-y-8">
            {certificates.map((cert, index) => (
              <motion.div
                key={cert.id}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="group"
              >
                <div className="flex gap-6 items-start">
                  {/* Timeline Dot */}
                  <div className="flex flex-col items-center">
                    <motion.div
                      whileHover={{ scale: 1.2 }}
                      className="w-12 h-12 rounded-full bg-gradient-to-br from-[#FEE440] to-[#00BBF9] flex items-center justify-center text-white shadow-lg"
                    >
                      <Award size={24} />
                    </motion.div>
                    {index !== certificates.length - 1 && (
                      <div className="w-1 h-16 bg-gradient-to-b from-[#00BBF9] to-[#00BBF9]/20 mt-2"></div>
                    )}
                  </div>

                  {/* Certificate Card */}
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="flex-1 bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all border border-[#00BBF9]/10"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {/* Image */}
                      <div className="md:col-span-1">
                        <img
                          src={cert.image || "/placeholder.svg"}
                          alt={cert.title}
                          className="w-full h-40 object-cover rounded-lg"
                        />
                      </div>

                      {/* Content */}
                      <div className="md:col-span-2 space-y-3">
                        <h3 className="text-xl font-bold text-[#2D3748]">{cert.title}</h3>
                        <p className="text-[#556B7F] text-sm leading-relaxed">{cert.description}</p>

                        <div className="flex flex-col gap-2 pt-2">
                          <div className="flex items-center gap-2 text-[#556B7F] text-sm">
                            <Building2 size={16} className="text-[#00BBF9]" />
                            <span>{cert.issuer}</span>
                          </div>
                          <div className="flex items-center gap-2 text-[#556B7F] text-sm">
                            <Calendar size={16} className="text-[#FEE440]" />
                            <span>{cert.date}</span>
                          </div>
                        </div>

                        <motion.button
                          whileHover={{ x: 5 }}
                          className="inline-flex items-center gap-2 text-[#00BBF9] font-semibold hover:text-[#9B5DE5] transition-colors mt-4"
                        >
                          View Certificate
                          <span>→</span>
                        </motion.button>
                      </div>
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { number: "05", label: "Certificates Earned" },
              { number: "10+", label: "Courses Completed" },
              { number: "100%", label: "Commitment to Learning" },
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.2 }}
                className="text-center p-6 rounded-2xl bg-gradient-to-br from-[#FEE440]/10 to-[#00BBF9]/10 border border-[#00BBF9]/20"
              >
                <div className="text-4xl font-bold bg-gradient-to-r from-[#FEE440] to-[#00BBF9] bg-clip-text text-transparent mb-2">
                  {stat.number}
                </div>
                <p className="text-[#556B7F] font-medium">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
